package com.piusanggoro.beritaakakom;

public class DataBerita {
    public String judulBerita;
    public String isiBerita;
    public String tglPosting;
    public String gambarBerita;
}
